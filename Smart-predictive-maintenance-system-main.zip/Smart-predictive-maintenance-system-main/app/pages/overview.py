"""
Overview Page
"""

import streamlit as st
import pandas as pd
from app.utils import load_metrics, get_metric_icon, format_metric


def show_overview():
    """Display project overview and key metrics."""
    
    st.markdown("## 📊 Project Overview")
    st.markdown("---")
    
    # Project description
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.markdown("""
        ### NASA C-MAPSS Predictive Maintenance System
        
        This system predicts the **Remaining Useful Life (RUL)** of turbofan engines using 
        machine learning to enable proactive maintenance and prevent failures.
        
        **Key Features:**
        - 🔧 100 engines analyzed (training + test)
        - 📡 21 sensor measurements per cycle
        - ⚙️ 171 engineered features
        - 🤖 Random Forest Regressor model
        - 📊 Comprehensive performance evaluation
        """)
    
    with col2:
        st.info("""
        **Dataset**: NASA C-MAPSS FD001
        
        **Model**: Random Forest
        
        **Features**: 171 engineered
        
        **Metric**: RUL in cycles
        """)
    
    # Load metrics
    metrics = load_metrics()
    
    if metrics:
        st.markdown("---")
        st.markdown("### 🎯 Model Performance Summary")
        
        # Key metrics in columns
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                label="📊 MAE",
                value=f"{metrics['mae']:.2f} cycles",
                help="Mean Absolute Error - Average prediction error"
            )
        
        with col2:
            st.metric(
                label="📈 RMSE",
                value=f"{metrics['rmse']:.2f} cycles",
                help="Root Mean Square Error - Penalizes larger errors"
            )
        
        with col3:
            st.metric(
                label="🎯 R² Score",
                value=f"{metrics['r2']:.4f}",
                help="Coefficient of Determination - Variance explained"
            )
        
        with col4:
            st.metric(
                label="📉 MAPE",
                value=f"{metrics['mape']:.2f}%",
                help="Mean Absolute Percentage Error"
            )
        
        # Accuracy thresholds
        st.markdown("---")
        st.markdown("### ✓ Prediction Accuracy")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric(
                label="Within 10 Cycles",
                value=f"{metrics.get('accuracy_within_10_cycles', 0):.1f}%",
                help="Percentage of predictions within 10 cycles of actual"
            )
        
        with col2:
            st.metric(
                label="Within 20 Cycles",
                value=f"{metrics.get('accuracy_within_20_cycles', 0):.1f}%",
                help="Percentage of predictions within 20 cycles of actual"
            )
        
        with col3:
            total_predictions = 13096  # Test set size
            st.metric(
                label="Total Predictions",
                value=f"{total_predictions:,}",
                help="Total number of predictions made"
            )
    
    else:
        st.warning("⚠️ No metrics available. Please run the pipeline first: `python main.py`")
    
    # Technical details
    st.markdown("---")
    st.markdown("### 🛠️ Technical Details")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        **Data Processing:**
        - Automated data loading and validation
        - Missing value detection
        - Feature scaling and normalization
        - RUL computation for each timestep
        
        **Feature Engineering:**
        - Rolling window features (mean, std)
        - Statistical aggregations (mean, std, max)
        - Per-unit feature deviations
        - 171 total engineered features
        """)
    
    with col2:
        st.markdown("""
        **Machine Learning:**
        - Random Forest Regressor (100 trees)
        - Train/validation split (80/20)
        - Feature importance analysis
        - Cross-platform compatible
        
        **Evaluation:**
        - Comprehensive metrics (MAE, RMSE, R², MAPE)
        - Per-unit error analysis
        - Predictions vs actual comparison
        - Residual distribution analysis
        """)
    
    # Use cases
    st.markdown("---")
    st.markdown("### 💡 Use Cases")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        **Predictive Maintenance**
        - Schedule maintenance proactively
        - Reduce unexpected failures
        - Optimize maintenance costs
        """)
    
    with col2:
        st.markdown("""
        **Resource Planning**
        - Plan spare parts inventory
        - Allocate maintenance resources
        - Minimize downtime
        """)
    
    with col3:
        st.markdown("""
        **Safety & Compliance**
        - Prevent catastrophic failures
        - Meet regulatory requirements
        - Improve fleet reliability
        """)

