"""
Data Insights Page
"""

import streamlit as st
import pandas as pd
from app.utils import (
    load_processed_data,
    create_correlation_heatmap,
    create_degradation_plot,
    create_rul_distribution,
    create_operational_settings_plot,
    calculate_summary_stats
)


def show_data_insights():
    """Display data insights and visualizations."""
    
    st.markdown("## 📊 Data Insights")
    st.markdown("Explore sensor patterns, correlations, and RUL distributions")
    st.markdown("---")
    
    # Load data
    with st.spinner("Loading data..."):
        train_df = load_processed_data('train')
        test_df = load_processed_data('test')
    
    if train_df is None or test_df is None:
        st.error("❌ Data not available. Please run the pipeline first: `python main.py`")
        return
    
    # Tabs for different insights
    tab1, tab2, tab3, tab4 = st.tabs([
        "📈 RUL Distribution", 
        "🔗 Sensor Correlations", 
        "📉 Degradation Patterns", 
        "⚙️ Operational Settings"
    ])
    
    # Tab 1: RUL Distribution
    with tab1:
        st.markdown("### Remaining Useful Life Distribution")
        st.markdown("Compare RUL distributions between training and test sets")
        
        # Summary statistics
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Training Set Statistics:**")
            train_stats = calculate_summary_stats(train_df, 'RUL')
            stats_df = pd.DataFrame({
                'Statistic': ['Mean', 'Median', 'Std Dev', 'Min', 'Max', 'Q25', 'Q75'],
                'Value (cycles)': [
                    f"{train_stats['mean']:.2f}",
                    f"{train_stats['median']:.2f}",
                    f"{train_stats['std']:.2f}",
                    f"{train_stats['min']:.2f}",
                    f"{train_stats['max']:.2f}",
                    f"{train_stats['q25']:.2f}",
                    f"{train_stats['q75']:.2f}"
                ]
            })
            st.dataframe(stats_df, use_container_width=True, hide_index=True)
        
        with col2:
            st.markdown("**Test Set Statistics:**")
            test_stats = calculate_summary_stats(test_df, 'RUL')
            stats_df = pd.DataFrame({
                'Statistic': ['Mean', 'Median', 'Std Dev', 'Min', 'Max', 'Q25', 'Q75'],
                'Value (cycles)': [
                    f"{test_stats['mean']:.2f}",
                    f"{test_stats['median']:.2f}",
                    f"{test_stats['std']:.2f}",
                    f"{test_stats['min']:.2f}",
                    f"{test_stats['max']:.2f}",
                    f"{test_stats['q25']:.2f}",
                    f"{test_stats['q75']:.2f}"
                ]
            })
            st.dataframe(stats_df, use_container_width=True, hide_index=True)
        
        # Distribution plot
        st.markdown("---")
        with st.spinner("Generating RUL distribution plot..."):
            fig = create_rul_distribution(train_df, test_df)
            st.pyplot(fig)
        
        st.info("💡 **Insight**: The training set shows the complete lifecycle of engines (RUL from max to 0), "
                "while the test set represents engines at various stages of operation.")
    
    # Tab 2: Sensor Correlations
    with tab2:
        st.markdown("### Sensor Correlation Analysis")
        st.markdown("Identify relationships between different sensors")
        
        # Sensor selection
        sensor_cols = [col for col in train_df.columns if col.startswith('sensor_') and '_' not in col[7:]]
        
        col1, col2 = st.columns([2, 1])
        with col1:
            selected_sensors = st.multiselect(
                "Select sensors to analyze (leave empty for all):",
                sensor_cols,
                default=sensor_cols[:10] if len(sensor_cols) > 10 else sensor_cols
            )
        
        with col2:
            dataset = st.radio("Dataset:", ["Training", "Test"])
        
        df_to_use = train_df if dataset == "Training" else test_df
        sensors_to_plot = selected_sensors if selected_sensors else sensor_cols
        
        if sensors_to_plot:
            st.markdown("---")
            with st.spinner("Generating correlation heatmap..."):
                fig = create_correlation_heatmap(df_to_use, sensors_to_plot)
                st.pyplot(fig)
            
            # Correlation insights
            corr_matrix = df_to_use[sensors_to_plot].corr()
            high_corr = []
            for i in range(len(corr_matrix.columns)):
                for j in range(i+1, len(corr_matrix.columns)):
                    if abs(corr_matrix.iloc[i, j]) > 0.8:
                        high_corr.append((
                            corr_matrix.columns[i],
                            corr_matrix.columns[j],
                            corr_matrix.iloc[i, j]
                        ))
            
            if high_corr:
                st.markdown("### 🔍 Highly Correlated Sensors (|r| > 0.8)")
                corr_df = pd.DataFrame(high_corr, columns=['Sensor 1', 'Sensor 2', 'Correlation'])
                st.dataframe(corr_df, use_container_width=True, hide_index=True)
    
    # Tab 3: Degradation Patterns
    with tab3:
        st.markdown("### Sensor Degradation Patterns")
        st.markdown("Observe how sensor values change over time as engines degrade")
        
        # Unit selection
        col1, col2 = st.columns([2, 1])
        
        with col1:
            num_units = st.slider("Number of units to display:", 1, 10, 5)
            units_to_plot = st.multiselect(
                "Or select specific units:",
                sorted(train_df['unit'].unique()),
                default=list(train_df['unit'].unique()[:num_units])
            )
        
        with col2:
            key_sensors = ['sensor_2', 'sensor_3', 'sensor_4', 'sensor_7', 'sensor_11', 'sensor_15']
            available_sensors = [s for s in key_sensors if s in train_df.columns]
            selected_plot_sensors = st.multiselect(
                "Select sensors:",
                available_sensors,
                default=available_sensors[:4]
            )
        
        if units_to_plot and selected_plot_sensors:
            st.markdown("---")
            with st.spinner("Generating degradation plots..."):
                fig = create_degradation_plot(train_df, units_to_plot, selected_plot_sensors)
                st.pyplot(fig)
            
            st.info("💡 **Insight**: Sensor values typically show increasing/decreasing trends as engines "
                    "approach failure, indicating progressive degradation.")
    
    # Tab 4: Operational Settings
    with tab4:
        st.markdown("### Operational Settings Analysis")
        st.markdown("Explore relationships between operational settings and sensor readings")
        
        st.markdown("---")
        with st.spinner("Generating operational settings plots..."):
            fig = create_operational_settings_plot(train_df)
            st.pyplot(fig)
        
        # Operational settings summary
        st.markdown("### 📋 Operational Settings Summary")
        
        op_settings = ['op_setting_1', 'op_setting_2', 'op_setting_3']
        op_data = []
        
        for setting in op_settings:
            if setting in train_df.columns:
                op_data.append({
                    'Setting': setting.replace('_', ' ').title(),
                    'Mean': f"{train_df[setting].mean():.4f}",
                    'Std': f"{train_df[setting].std():.4f}",
                    'Min': f"{train_df[setting].min():.4f}",
                    'Max': f"{train_df[setting].max():.4f}"
                })
        
        if op_data:
            op_df = pd.DataFrame(op_data)
            st.dataframe(op_df, use_container_width=True, hide_index=True)
        
        st.info("💡 **Insight**: Operational settings represent different flight conditions "
                "(altitude, Mach number, throttle resolver angle). The scatter plots show how "
                "these settings affect sensor readings and RUL.")

