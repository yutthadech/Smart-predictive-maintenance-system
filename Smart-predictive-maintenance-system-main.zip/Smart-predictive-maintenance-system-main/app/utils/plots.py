"""
Plotting utilities
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend to avoid tkinter issues
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st


def create_correlation_heatmap(df, sensors=None):
    """Create sensor correlation heatmap."""
    if sensors is None:
        sensors = [col for col in df.columns if col.startswith('sensor_') and '_' not in col[7:]]
    
    corr = df[sensors].corr()
    
    fig, ax = plt.subplots(figsize=(12, 10))
    sns.heatmap(corr, annot=False, cmap='coolwarm', center=0, 
                square=True, linewidths=0.5, cbar_kws={"shrink": 0.8}, ax=ax)
    ax.set_title('Sensor Correlation Heatmap', fontsize=16, fontweight='bold', pad=20)
    plt.tight_layout()
    
    return fig


def create_degradation_plot(df, units, sensors=None):
    """Create sensor degradation patterns plot."""
    if sensors is None:
        sensors = ['sensor_2', 'sensor_3', 'sensor_4', 'sensor_7']
    
    sensors = [s for s in sensors if s in df.columns]
    
    fig, axes = plt.subplots(2, 2, figsize=(16, 10))
    axes = axes.flatten()
    
    colors = plt.cm.tab10(np.linspace(0, 1, len(units)))
    
    for idx, sensor in enumerate(sensors[:4]):
        ax = axes[idx]
        
        for unit_idx, unit in enumerate(units):
            unit_data = df[df['unit'] == unit].sort_values('time')
            ax.plot(unit_data['time'], unit_data[sensor], 
                   label=f'Unit {unit}', alpha=0.7, linewidth=2, color=colors[unit_idx])
        
        ax.set_xlabel('Time (cycles)', fontsize=12)
        ax.set_ylabel('Sensor Value', fontsize=12)
        ax.set_title(f'{sensor.replace("_", " ").title()} Degradation', 
                    fontsize=14, fontweight='bold')
        ax.legend(loc='best', fontsize=10)
        ax.grid(alpha=0.3)
    
    plt.tight_layout()
    return fig


def create_rul_distribution(train_df, test_df):
    """Create RUL distribution plots."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # Training RUL
    axes[0].hist(train_df['RUL'], bins=50, alpha=0.7, color='steelblue', edgecolor='black')
    axes[0].axvline(train_df['RUL'].mean(), color='red', linestyle='--', 
                    linewidth=2, label=f'Mean: {train_df["RUL"].mean():.1f}')
    axes[0].set_xlabel('Remaining Useful Life (cycles)', fontsize=12)
    axes[0].set_ylabel('Frequency', fontsize=12)
    axes[0].set_title('Training Set RUL Distribution', fontsize=14, fontweight='bold')
    axes[0].legend()
    axes[0].grid(alpha=0.3)
    
    # Test RUL
    axes[1].hist(test_df['RUL'], bins=50, alpha=0.7, color='coral', edgecolor='black')
    axes[1].axvline(test_df['RUL'].mean(), color='red', linestyle='--',
                    linewidth=2, label=f'Mean: {test_df["RUL"].mean():.1f}')
    axes[1].set_xlabel('Remaining Useful Life (cycles)', fontsize=12)
    axes[1].set_ylabel('Frequency', fontsize=12)
    axes[1].set_title('Test Set RUL Distribution', fontsize=14, fontweight='bold')
    axes[1].legend()
    axes[1].grid(alpha=0.3)
    
    plt.tight_layout()
    return fig


def create_predictions_plot(predictions_df):
    """Create predictions vs actual plot."""
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    # Scatter plot
    ax1 = axes[0]
    ax1.scatter(predictions_df['actual_RUL'], predictions_df['predicted_RUL'], 
               alpha=0.5, s=20, color='steelblue', edgecolors='black', linewidth=0.5)
    
    max_val = max(predictions_df['actual_RUL'].max(), predictions_df['predicted_RUL'].max())
    ax1.plot([0, max_val], [0, max_val], 'r--', linewidth=2, label='Perfect Prediction')
    
    ax1.set_xlabel('Actual RUL (cycles)', fontsize=12, fontweight='bold')
    ax1.set_ylabel('Predicted RUL (cycles)', fontsize=12, fontweight='bold')
    ax1.set_title('Predictions vs Actual RUL', fontsize=14, fontweight='bold')
    ax1.legend()
    ax1.grid(alpha=0.3)
    
    # Error distribution
    ax2 = axes[1]
    errors = predictions_df['actual_RUL'] - predictions_df['predicted_RUL']
    ax2.hist(errors, bins=50, alpha=0.7, color='coral', edgecolor='black')
    ax2.axvline(0, color='red', linestyle='--', linewidth=2, label='Zero Error')
    ax2.axvline(errors.mean(), color='blue', linestyle='--', linewidth=2, 
               label=f'Mean Error: {errors.mean():.2f}')
    ax2.set_xlabel('Prediction Error (cycles)', fontsize=12, fontweight='bold')
    ax2.set_ylabel('Frequency', fontsize=12, fontweight='bold')
    ax2.set_title('Error Distribution', fontsize=14, fontweight='bold')
    ax2.legend()
    ax2.grid(alpha=0.3)
    
    plt.tight_layout()
    return fig


def create_feature_importance_plot(importance_df, top_n=20):
    """Create feature importance bar plot."""
    top_features = importance_df.head(top_n)
    
    fig, ax = plt.subplots(figsize=(12, max(8, top_n * 0.3)))
    
    colors = plt.cm.viridis(np.linspace(0.3, 0.9, len(top_features)))
    bars = ax.barh(range(len(top_features)), top_features['importance'], color=colors)
    
    ax.set_yticks(range(len(top_features)))
    ax.set_yticklabels(top_features['feature'], fontsize=10)
    ax.set_xlabel('Importance Score', fontsize=12, fontweight='bold')
    ax.set_title(f'Top {top_n} Most Important Features', fontsize=14, fontweight='bold')
    ax.invert_yaxis()
    ax.grid(axis='x', alpha=0.3)
    
    plt.tight_layout()
    return fig


def create_unit_rul_plot(predictions_df, unit):
    """Create RUL plot for a specific unit."""
    unit_data = predictions_df[predictions_df['unit'] == unit].sort_values('time')
    
    fig, ax = plt.subplots(figsize=(14, 6))
    ax.plot(unit_data['time'], unit_data['actual_RUL'], 
           label='Actual RUL', linewidth=3, color='green', marker='o', markersize=4)
    ax.plot(unit_data['time'], unit_data['predicted_RUL'], 
           label='Predicted RUL', linewidth=3, color='blue', linestyle='--', marker='s', markersize=4)
    ax.fill_between(unit_data['time'], 
                     unit_data['actual_RUL'], 
                     unit_data['predicted_RUL'],
                     alpha=0.3, color='gray', label='Error')
    
    ax.set_xlabel('Time (cycles)', fontsize=12, fontweight='bold')
    ax.set_ylabel('Remaining Useful Life (cycles)', fontsize=12, fontweight='bold')
    ax.set_title(f'Unit {unit} - RUL Prediction vs Actual', fontsize=14, fontweight='bold')
    ax.legend(fontsize=11)
    ax.grid(alpha=0.3)
    
    plt.tight_layout()
    return fig


def create_operational_settings_plot(df):
    """Create operational settings scatter plots."""
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    op_settings = ['op_setting_1', 'op_setting_2', 'op_setting_3']
    
    for idx, setting in enumerate(op_settings):
        if setting in df.columns and 'sensor_4' in df.columns:
            scatter = axes[idx].scatter(df[setting], df['sensor_4'], 
                                       c=df['RUL'], cmap='coolwarm', 
                                       alpha=0.5, s=10, edgecolors='none')
            axes[idx].set_xlabel(f'{setting.replace("_", " ").title()}', fontsize=12)
            axes[idx].set_ylabel('Sensor 4', fontsize=12)
            axes[idx].set_title(f'{setting.replace("_", " ").title()} vs Sensor 4', 
                               fontsize=14, fontweight='bold')
            plt.colorbar(scatter, ax=axes[idx], label='RUL')
            axes[idx].grid(alpha=0.3)
    
    plt.tight_layout()
    return fig

