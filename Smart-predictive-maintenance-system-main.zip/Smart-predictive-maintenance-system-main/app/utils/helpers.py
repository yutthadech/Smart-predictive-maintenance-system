"""
Helper utilities
"""

import pandas as pd
import streamlit as st
import matplotlib
matplotlib.use('Agg')  # Ensure non-interactive backend


def configure_matplotlib():
    """Configure matplotlib to avoid tkinter issues."""
    import matplotlib.pyplot as plt
    plt.ioff()  # Turn off interactive mode
    return plt


def format_metric(value, metric_type='number'):
    """Format metric values for display."""
    if metric_type == 'number':
        return f"{value:,.0f}"
    elif metric_type == 'decimal':
        return f"{value:.4f}"
    elif metric_type == 'percentage':
        return f"{value:.2f}%"
    elif metric_type == 'cycles':
        return f"{value:.2f} cycles"
    return str(value)


def get_metric_icon(metric_name):
    """Get icon for metric."""
    icons = {
        'mae': '📊',
        'rmse': '📈',
        'r2': '🎯',
        'mape': '📉',
        'accuracy': '✓',
        'engines': '🔧',
        'sensors': '📡',
        'features': '⚙️',
        'predictions': '🔮',
        'rul': '⏱️'
    }
    return icons.get(metric_name.lower(), '📌')


def style_dataframe(df):
    """Apply styling to dataframe."""
    return df.style.background_gradient(cmap='YlOrRd', subset=pd.IndexSlice[:, df.select_dtypes(include='number').columns])


def create_metric_card(title, value, delta=None, icon='📊'):
    """Create a styled metric card."""
    col1, col2 = st.columns([1, 4])
    with col1:
        st.markdown(f"<div style='font-size: 3rem;'>{icon}</div>", unsafe_allow_html=True)
    with col2:
        st.metric(label=title, value=value, delta=delta)


def filter_predictions(predictions_df, rul_range=None, error_range=None, units=None):
    """Filter predictions based on criteria."""
    filtered = predictions_df.copy()
    
    if rul_range:
        filtered = filtered[(filtered['actual_RUL'] >= rul_range[0]) & 
                           (filtered['actual_RUL'] <= rul_range[1])]
    
    if error_range:
        filtered = filtered[(filtered['abs_error'] >= error_range[0]) & 
                           (filtered['abs_error'] <= error_range[1])]
    
    if units:
        filtered = filtered[filtered['unit'].isin(units)]
    
    return filtered


def get_maintenance_recommendation(predicted_rul, threshold_critical=20, threshold_warning=50):
    """Get maintenance recommendation based on predicted RUL."""
    if predicted_rul <= threshold_critical:
        return {
            'status': 'Critical',
            'action': 'Immediate maintenance required',
            'color': 'red',
            'icon': '🚨'
        }
    elif predicted_rul <= threshold_warning:
        return {
            'status': 'Warning',
            'action': 'Schedule maintenance soon',
            'color': 'orange',
            'icon': '⚠️'
        }
    else:
        return {
            'status': 'Normal',
            'action': 'Continue monitoring',
            'color': 'green',
            'icon': '✅'
        }


def calculate_summary_stats(df, column='RUL'):
    """Calculate summary statistics for a column."""
    return {
        'mean': df[column].mean(),
        'median': df[column].median(),
        'std': df[column].std(),
        'min': df[column].min(),
        'max': df[column].max(),
        'q25': df[column].quantile(0.25),
        'q75': df[column].quantile(0.75)
    }


@st.cache_data
def convert_df_to_csv(df):
    """Convert dataframe to CSV for download."""
    return df.to_csv(index=False).encode('utf-8')

