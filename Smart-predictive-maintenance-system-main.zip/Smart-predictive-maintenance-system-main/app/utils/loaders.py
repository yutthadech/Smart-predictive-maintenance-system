"""
Data loading utilities
"""

import os
import json
import pandas as pd
import joblib
import streamlit as st


@st.cache_resource
def load_model():
    """Load trained model."""
    model_path = os.path.join('models', 'random_forest_rul_model.pkl')
    if os.path.exists(model_path):
        return joblib.load(model_path)
    return None


@st.cache_data
def load_metrics():
    """Load test metrics."""
    metrics_path = os.path.join('outputs', 'test_metrics.json')
    if os.path.exists(metrics_path):
        with open(metrics_path, 'r') as f:
            return json.load(f)
    return None


@st.cache_data
def load_predictions():
    """Load predictions."""
    predictions_path = os.path.join('outputs', 'predictions.csv')
    if os.path.exists(predictions_path):
        return pd.read_csv(predictions_path)
    return None


@st.cache_data
def load_feature_importance():
    """Load feature importance."""
    importance_path = os.path.join('outputs', 'feature_importance.csv')
    if os.path.exists(importance_path):
        return pd.read_csv(importance_path)
    return None


@st.cache_data
def load_processed_data(dataset='train'):
    """Load processed train or test data."""
    if dataset == 'train':
        path = os.path.join('outputs', 'processed_train.csv')
    else:
        path = os.path.join('outputs', 'processed_test.csv')
    
    if os.path.exists(path):
        return pd.read_csv(path)
    return None


def check_data_availability():
    """Check if all required data files exist."""
    required_files = [
        'models/random_forest_rul_model.pkl',
        'outputs/test_metrics.json',
        'outputs/predictions.csv',
        'outputs/feature_importance.csv',
        'outputs/processed_train.csv',
        'outputs/processed_test.csv'
    ]
    
    missing = [f for f in required_files if not os.path.exists(f)]
    
    return len(missing) == 0, missing

