"""
Enhanced Streamlit App for NASA C-MAPSS Predictive Maintenance System
======================================================================

Interactive dashboard for visualizing model results and predictions.

Usage:
    streamlit run app/main_app_enhanced.py
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import streamlit as st
import pandas as pd
import numpy as np

# Configure page
st.set_page_config(
    page_title="Smart Predictive Maintenance",
    page_icon="🔧",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# Custom CSS for modern UI
st.markdown("""
<style>
    /* Main styling */
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        text-align: center;
        background: linear-gradient(90deg, #1f77b4, #2ca02c);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        text-align: center;
        color: #666;
        margin-bottom: 2rem;
    }
    
    /* Tab styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 2rem;
    }
    .stTabs [data-baseweb="tab"] {
        height: 3rem;
        padding: 0 2rem;
        background-color: #f0f2f6;
        border-radius: 0.5rem 0.5rem 0 0;
    }
    .stTabs [aria-selected="true"] {
        background-color: #ffffff;
    }
    
    /* Metric cards */
    [data-testid="stMetricValue"] {
        font-size: 1.8rem;
    }
    
    /* Buttons */
    .stButton>button {
        width: 100%;
        border-radius: 0.5rem;
        font-weight: bold;
    }
    
    /* Info boxes */
    .stAlert {
        border-radius: 0.5rem;
    }
</style>
""", unsafe_allow_html=True)

# Import utilities
from app.utils.loaders import (
    load_model, load_metrics, load_predictions, 
    load_feature_importance, load_processed_data,
    check_data_availability
)
from app.utils.plots import (
    create_correlation_heatmap, create_degradation_plot,
    create_rul_distribution, create_predictions_plot,
    create_feature_importance_plot, create_unit_rul_plot
)
from app.utils.helpers import (
    format_metric, get_metric_icon, filter_predictions,
    get_maintenance_recommendation, convert_df_to_csv,
    calculate_summary_stats
)


def main():
    """Main application."""
    
    # Header
    st.markdown('<h1 class="main-header">🔧 Smart Predictive Maintenance System</h1>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">NASA C-MAPSS FD001 | Remaining Useful Life Prediction with ML</p>', unsafe_allow_html=True)
    
    # Check data availability
    data_available, missing_files = check_data_availability()
    
    if not data_available:
        st.error("❌ **Data Not Available**")
        st.warning("Please run the pipeline first to generate outputs:")
        st.code("python main.py", language="bash")
        st.markdown("**Missing files:**")
        for file in missing_files:
            st.markdown(f"- `{file}`")
        return
    
    # Navigation tabs
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "📊 Overview",
        "📈 Data Insights",
        "🎯 Model Performance",
        "🔮 Predictions",
        "🔧 Maintenance Insights",
        "💡 Interactive Prediction"
    ])
    
    # Tab 1: Overview
    with tab1:
        show_overview_tab()
    
    # Tab 2: Data Insights
    with tab2:
        show_data_insights_tab()
    
    # Tab 3: Model Performance
    with tab3:
        show_model_performance_tab()
    
    # Tab 4: Predictions
    with tab4:
        show_predictions_tab()
    
    # Tab 5: Maintenance Insights
    with tab5:
        show_maintenance_insights_tab()
    
    # Tab 6: Interactive Prediction
    with tab6:
        show_interactive_prediction_tab()


def show_overview_tab():
    """Overview tab content."""
    from app.pages.overview import show_overview
    show_overview()


def show_data_insights_tab():
    """Data insights tab content."""
    from app.pages.data_insights import show_data_insights
    show_data_insights()


def show_model_performance_tab():
    """Model performance tab."""
    st.markdown("## 🎯 Model Performance")
    st.markdown("---")
    
    metrics = load_metrics()
    predictions = load_predictions()
    
    if not metrics or predictions is None:
        st.warning("No data available")
        return
    
    # Performance metrics
    st.markdown("### 📊 Test Set Performance")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="📊 MAE",
            value=f"{metrics['mae']:.2f}",
            help="Mean Absolute Error"
        )
    
    with col2:
        st.metric(
            label="📈 RMSE",
            value=f"{metrics['rmse']:.2f}",
            help="Root Mean Square Error"
        )
    
    with col3:
        st.metric(
            label="🎯 R² Score",
            value=f"{metrics['r2']:.4f}",
            help="Coefficient of Determination"
        )
    
    with col4:
        st.metric(
            label="📉 MAPE",
            value=f"{metrics['mape']:.2f}%",
            help="Mean Absolute Percentage Error"
        )
    
    # Visualizations
    st.markdown("---")
    st.markdown("### 📈 Predictions vs Actual")
    
    with st.spinner("Generating plots..."):
        fig = create_predictions_plot(predictions)
        st.pyplot(fig)
    
    # Download predictions
    st.markdown("---")
    col1, col2 = st.columns([3, 1])
    with col1:
        st.markdown("### 💾 Export Predictions")
    with col2:
        csv = convert_df_to_csv(predictions)
        st.download_button(
            label="Download CSV",
            data=csv,
            file_name="predictions.csv",
            mime="text/csv"
        )


def show_predictions_tab():
    """Predictions analysis tab."""
    st.markdown("## 🔮 Predictions Analysis")
    st.markdown("---")
    
    predictions = load_predictions()
    
    if predictions is None:
        st.warning("No predictions available")
        return
    
    # Filters
    st.markdown("### 🔍 Filter Predictions")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        rul_min = st.number_input("Min RUL", 0, int(predictions['actual_RUL'].max()), 0)
        rul_max = st.number_input("Max RUL", 0, int(predictions['actual_RUL'].max()), int(predictions['actual_RUL'].max()))
    
    with col2:
        error_min = st.number_input("Min Error", 0, int(predictions['abs_error'].max()), 0)
        error_max = st.number_input("Max Error", 0, int(predictions['abs_error'].max()), int(predictions['abs_error'].max()))
    
    with col3:
        units = st.multiselect(
            "Select Units",
            sorted(predictions['unit'].unique()),
            default=[]
        )
    
    # Apply filters
    filtered = filter_predictions(
        predictions,
        rul_range=(rul_min, rul_max),
        error_range=(error_min, error_max),
        units=units if units else None
    )
    
    st.info(f"📊 Showing {len(filtered):,} of {len(predictions):,} predictions")
    
    # Worst performers
    st.markdown("---")
    st.markdown("### ⚠️ Worst Predicted Units")
    
    unit_errors = predictions.groupby('unit')['abs_error'].mean().sort_values(ascending=False).head(10)
    worst_df = pd.DataFrame({
        'Unit': unit_errors.index,
        'Mean Absolute Error': unit_errors.values.round(2)
    })
    st.dataframe(worst_df, use_container_width=True, hide_index=True)
    
    # Unit-specific analysis
    st.markdown("---")
    st.markdown("### 🔍 Unit-Specific Analysis")
    
    selected_unit = st.selectbox("Select Unit", sorted(predictions['unit'].unique()))
    
    if selected_unit:
        with st.spinner(f"Loading Unit {selected_unit}..."):
            fig = create_unit_rul_plot(predictions, selected_unit)
            st.pyplot(fig)
        
        unit_data = predictions[predictions['unit'] == selected_unit]
        st.dataframe(unit_data[['time', 'actual_RUL', 'predicted_RUL', 'error', 'abs_error']], 
                    use_container_width=True, hide_index=True)


def show_maintenance_insights_tab():
    """Maintenance insights tab."""
    st.markdown("## 🔧 Maintenance Insights")
    st.markdown("---")
    
    predictions = load_predictions()
    feature_importance = load_feature_importance()
    
    if predictions is None or feature_importance is None:
        st.warning("No data available")
        return
    
    # Get latest predictions per unit
    latest_predictions = predictions.groupby('unit').last().reset_index()
    latest_predictions = latest_predictions.sort_values('predicted_RUL')
    
    # Count units by status
    critical_count = len(latest_predictions[latest_predictions['predicted_RUL'] < 20])
    warning_count = len(latest_predictions[(latest_predictions['predicted_RUL'] >= 20) & (latest_predictions['predicted_RUL'] < 50)])
    healthy_count = len(latest_predictions[latest_predictions['predicted_RUL'] >= 50])
    
    # Status overview
    st.markdown("### 📊 Fleet Status Overview")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            label="🚨 Critical",
            value=critical_count,
            help="RUL < 20 cycles - Immediate action required"
        )
    
    with col2:
        st.metric(
            label="⚠️ Warning",
            value=warning_count,
            help="20 ≤ RUL < 50 cycles - Schedule maintenance"
        )
    
    with col3:
        st.metric(
            label="✅ Healthy",
            value=healthy_count,
            help="RUL ≥ 50 cycles - Continue monitoring"
        )
    
    with col4:
        st.metric(
            label="📊 Total Units",
            value=len(latest_predictions),
            help="Total number of monitored units"
        )
    
    # Maintenance recommendations table
    st.markdown("---")
    st.markdown("### 🚨 Maintenance Recommendations")
    st.markdown("*Units sorted by urgency (lowest RUL first)*")
    
    # Create recommendations dataframe with color-coded status
    recommendations = []
    for idx, row in latest_predictions.iterrows():
        rul = row['predicted_RUL']
        
        # Determine status and action
        if rul < 20:
            status = "🚨 Critical"
            action = "Inspect and replace parts immediately"
            priority = 1
        elif rul < 50:
            status = "⚠️ Warning"
            action = "Schedule maintenance soon"
            priority = 2
        else:
            status = "✅ Healthy"
            action = "Continue monitoring"
            priority = 3
        
        recommendations.append({
            'Priority': priority,
            'Unit ID': int(row['unit']),
            'Status': status,
            'Predicted RUL': f"{rul:.0f} cycles",
            'Recommended Action': action
        })
    
    # Create DataFrame and display
    rec_df = pd.DataFrame(recommendations)
    rec_df = rec_df.sort_values('Priority')
    rec_df = rec_df.drop('Priority', axis=1)  # Remove priority column after sorting
    
    # Display with custom styling
    st.dataframe(
        rec_df,
        use_container_width=True,
        hide_index=True,
        height=400
    )
    
    # Critical units detailed view
    if critical_count > 0:
        st.markdown("---")
        st.markdown("### 🚨 Critical Units - Immediate Attention Required")
        st.error(f"**{critical_count} unit(s) require immediate maintenance!**")
        
        critical_units = latest_predictions[latest_predictions['predicted_RUL'] < 20]
        
        for idx, row in critical_units.head(5).iterrows():
            with st.container():
                col1, col2, col3 = st.columns([1, 3, 4])
                
                with col1:
                    st.markdown(f"<div style='font-size: 3rem; text-align: center;'>🚨</div>", unsafe_allow_html=True)
                
                with col2:
                    st.markdown(f"### Unit {int(row['unit'])}")
                    st.markdown(f"**RUL:** {row['predicted_RUL']:.0f} cycles")
                
                with col3:
                    st.markdown("#### Action Required:")
                    st.markdown("- ✓ Inspect and replace critical parts immediately")
                    st.markdown("- ✓ Schedule downtime for maintenance")
                    st.markdown("- ✓ Prepare replacement components")
                
                st.markdown("---")
    
    # Feature importance section
    st.markdown("---")
    st.markdown("### ⚙️ Feature Importance Analysis")
    st.markdown("*Understanding which sensor readings drive RUL predictions*")
    
    top_n = st.slider("Number of features to display", 10, 50, 20, key="feature_slider")
    
    with st.spinner("Generating feature importance plot..."):
        fig = create_feature_importance_plot(feature_importance, top_n)
        st.pyplot(fig)
    
    # Download feature importance
    col1, col2 = st.columns([3, 1])
    with col1:
        st.markdown("**Download feature importance data for further analysis**")
    with col2:
        csv = convert_df_to_csv(feature_importance)
        st.download_button(
            label="📥 Download CSV",
            data=csv,
            file_name="feature_importance.csv",
            mime="text/csv"
        )


def show_interactive_prediction_tab():
    """Interactive prediction tab."""
    st.markdown("## 💡 Interactive RUL Prediction")
    st.markdown("---")
    
    model = load_model()
    feature_importance = load_feature_importance()
    
    if model is None or feature_importance is None:
        st.warning("Model not available")
        return
    
    st.info("🚧 **Note**: This is a simplified demo. Full implementation requires proper feature scaling and preprocessing.")
    
    # Model info
    st.markdown("### 🤖 Model Information")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Model Type", "Random Forest")
    with col2:
        st.metric("Estimators", model.n_estimators if hasattr(model, 'n_estimators') else 'N/A')
    with col3:
        st.metric("Features", model.n_features_in_ if hasattr(model, 'n_features_in_') else 'N/A')
    
    # Top features
    st.markdown("---")
    st.markdown("### 🔑 Key Features for Prediction")
    
    top_features = feature_importance.head(10)
    st.dataframe(top_features, use_container_width=True, hide_index=True)
    
    st.markdown("""
    **💡 Insight**: The model relies heavily on:
    - **Sensor 11** rolling mean deviation (68% importance)
    - **Sensor 4** rolling statistics
    - **Sensor 3** unit maximum values
    
    These sensors capture critical degradation patterns in turbofan engines.
    """)


if __name__ == "__main__":
    main()

